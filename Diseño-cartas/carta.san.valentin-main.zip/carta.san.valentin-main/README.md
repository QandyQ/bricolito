# 💌 Carta Digital para San Valentín – 2 Versiones con HTML, CSS y JS 
### Video del tutorial: [https://youtu.be/USJThFamdKc](https://youtu.be/USJThFamdKc)

![carta-th-1](https://github.com/user-attachments/assets/226b6d0f-90b9-4f90-8c5e-75f372481e22)
